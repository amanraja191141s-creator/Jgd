import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const html=fs.readFileSync('index.html','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
test('GST surface is explicitly white in both global themes',()=>{
  assert.match(css,/body\[data-theme="dark"\] #screen-viewport #screen-salestax[\s\S]*?background:#f3f4f7 !important/);
  assert.match(css,/body\[data-theme="dark"\] #screen-viewport #screen-salestax \.gst-reference-card[\s\S]*?background:#fff !important/);
  assert.match(css,/body\[data-theme="dark"\] #screen-viewport #screen-salestax \.gst-amount-field[\s\S]*?background:transparent !important/);
});
test('GST amount and rate input outlines are fully removed',()=>{
  assert.match(css,/#tax-orig\.input-val-box,[\s\S]*?#tax-rate\.input-val-box[\s\S]*?border:0 !important[\s\S]*?outline:0 !important/);
});
test('GST rate entry retains visible left-aligned input and quick rates',()=>{
  assert.match(html,/id="tax-rate" data-target="tax-rate" data-placeholder="Add rate"/);
  assert.match(css,/\.gst-rate-field \.reference-input-suffix[\s\S]*?grid-column:2 !important/);
  assert.match(css,/\.gst-quick-rates[\s\S]*?grid-column:3 !important/);
});
test('GST mode and state controls have compact visible rows above dock',()=>{
  assert.match(css,/\.gst-choice-row[\s\S]*?height:40px !important/);
  assert.match(css,/\.gst-reference-layout[\s\S]*?overflow-y:auto !important/);
  assert.match(css,/padding:10px 14px calc\(var\(--tool-keypad-height/);
});
test('GST active keypad background and keys remain light under dark app theme',()=>{
  assert.match(css,/body\[data-theme="dark"\]:has\(#screen-viewport #screen-salestax\.active\) #tool-keypad-dock[\s\S]*?background:#f3f4f7 !important/);
  assert.match(css,/body:has\(#screen-viewport #screen-salestax\.active\) #tool-keypad-dock \.tool-keypad-grid > \.key-btn[\s\S]*?background:#fff !important/);
});
test('v98.84 release identity is synchronized',()=>{
  assert.equal(pkg.version,'1.98.98-v98.84'); assert.equal(pkg.androidVersionCode,1099104);
  assert.equal(manifest.version,pkg.version); assert.match(html,/1\.98\.98-v98\.84/);
  assert.match(workflow,/1\.98\.98-v98\.84/); assert.match(workflow,/1099104/);
  assert.match(workflow,/gst-white-theme-layout-v9884\.test\.mjs/);
});
